import { combineReducers } from "redux";
import cars from './car'

export default combineReducers({
    cars
});